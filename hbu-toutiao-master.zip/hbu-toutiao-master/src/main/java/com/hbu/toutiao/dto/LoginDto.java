package com.hbu.toutiao.dto;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class LoginDto {
    public String email;
    public String password;
}

