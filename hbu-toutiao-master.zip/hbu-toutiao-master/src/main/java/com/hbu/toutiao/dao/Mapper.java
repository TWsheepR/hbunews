package com.hbu.toutiao.dao;

public @interface Mapper {
}
